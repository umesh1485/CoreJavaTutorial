package com.intrfc;

public class MyInterfaceImpl implements MyInteface{
	
	
	public void printName(){
		System.out.println("Name: "+name);
	}
	
	public void printage(){
		System.out.println("Age:"+age);
	}
	
	public void job(){
		System.out.println("SE");
	}
	
}
