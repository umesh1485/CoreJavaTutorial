package com.intrfc;

public interface A {
	void print();
	void methodOfA1();
}
