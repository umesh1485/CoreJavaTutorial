package com.intrfc;

public class MyInterFaceImpl2 implements MyInteface{

	public void printName(){
		System.out.println("Name: "+"Rakesh Sonkar");
	}
	
	public void printage(){
		System.out.println("Age:"+"27");
	}
}
