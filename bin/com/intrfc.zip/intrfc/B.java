package com.intrfc;

public interface B {
	void print();
	void methodOfB();
}
