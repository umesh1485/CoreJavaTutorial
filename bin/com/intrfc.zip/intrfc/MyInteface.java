package com.intrfc;

public interface MyInteface {

	final static String name = "umesh";
	int age=20;
	
	abstract void printName();
	void printage();
	
}
