package com.inheritance;

public class Cat extends Animal{
	private boolean nonVeg;

	
	public boolean isNonVeg() {
		
		return nonVeg;
	}

	public void setNonVeg(boolean nonVeg) {
		this.nonVeg = nonVeg;
	}
}
