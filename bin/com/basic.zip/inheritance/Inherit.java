package com.inheritance;

public class Inherit extends Props{

	public static void main(String[] args) {
		Inherit obj = new Inherit();
		System.out.println(obj.name);
		System.out.println(obj.age);
	}

}
