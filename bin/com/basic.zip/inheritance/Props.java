package com.inheritance;

public class Props {

	public String name="Umesh";
	public int age=30;
}
