package com.inheritance;

import com.inheritance.Animal;

public class Cow extends Animal{
	private boolean veg;

	public boolean isVeg() {
		return veg;
	}

	public void setVeg(boolean veg) {
		this.veg = veg;
	}


}
